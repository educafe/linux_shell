#!/bin/bash
# This is comment line
echo "Hello World"
ls
date
