#!/bin/bash
variable1=$1
variable2=${2:-$variable1}
echo $variable1
echo $variable2
