#!/bin/bash
planet="Earth"
echo $planet
echo "$planet"
echo '$planet'
echo \$planet
echo Enter some text
read planet
echo '$planet' now equals $planet
exit 0
