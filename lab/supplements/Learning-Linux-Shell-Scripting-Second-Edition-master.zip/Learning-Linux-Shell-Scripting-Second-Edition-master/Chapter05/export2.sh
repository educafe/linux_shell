#!/bin/bash
echo "$foo"
echo "$bar"
