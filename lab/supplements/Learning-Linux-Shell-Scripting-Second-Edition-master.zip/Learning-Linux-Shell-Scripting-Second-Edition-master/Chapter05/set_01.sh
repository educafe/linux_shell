#!/bin/bash
set USA Canada UK France
echo $1
echo $2
echo $3
echo $4
