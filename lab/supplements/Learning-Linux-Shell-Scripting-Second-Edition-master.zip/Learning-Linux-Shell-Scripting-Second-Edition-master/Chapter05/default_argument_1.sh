#!/bin/bash
MY_PARAM=${1:-default}
echo $MY_PARAM
