#!/bin/bash
foo="The first variable foo"
export bar="The second variable bar"
./export2.sh

