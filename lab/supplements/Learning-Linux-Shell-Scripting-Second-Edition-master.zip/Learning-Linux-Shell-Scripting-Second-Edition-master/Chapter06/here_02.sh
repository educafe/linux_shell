#!/bin/bash
sort << EOF
cherry
mango
apple
banana
EOF
