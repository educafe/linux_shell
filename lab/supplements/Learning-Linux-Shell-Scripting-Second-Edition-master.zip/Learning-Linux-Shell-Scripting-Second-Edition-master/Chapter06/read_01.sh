#!/bin/bash
echo "Where do you stay ?"
read # we have not supplied any option or variable
echo "You stay in $REPLY"
