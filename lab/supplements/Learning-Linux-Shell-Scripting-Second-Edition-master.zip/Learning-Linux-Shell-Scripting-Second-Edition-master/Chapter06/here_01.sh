#!/bin/bash
cat << quit
Command is $0
First Argument is $1
Second Argument is $2
quit
