#!/bin/bash
echo "Commands in bin directory are : $var"
for var in $(ls )
do
echo -n -e "$var "
do
