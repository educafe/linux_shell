#!/bin/bash -n
We have modified shebang line.
