#!/bin/bash
echo "What is your name?"
read fname mname lname
echo "Your first name is : $fname"
echo "Your middle name is : $mname"
echo "Your last name is : $lname"
