#!/bin/bash
wc -w <<< 'Good Morning and have a nice day !'
