#!/bin/bash
select var1 in a bc def ghi jkl
do
echo "Present value of var1 is" $var1
done
