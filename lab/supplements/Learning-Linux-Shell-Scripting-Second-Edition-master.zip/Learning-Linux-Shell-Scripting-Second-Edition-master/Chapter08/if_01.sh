#!/bin/bash
a=100
if [ $a -eq 100 ]
then
echo "a is equal to $a"
else
echo "a is not equal"
fi
