#!/bin/bash
for value in 10 5 27 33 14 25
do
echo $value
done | sort -n
