#!/bin/bash
for animal in Tiger Lion Cat Dog
do
echo $animal
sleep 1
done &
