#!/bin/bash
max=10
for ((i=1; i<=max; i++))
do
echo -n "$i " # one case with echo without –n option
done
