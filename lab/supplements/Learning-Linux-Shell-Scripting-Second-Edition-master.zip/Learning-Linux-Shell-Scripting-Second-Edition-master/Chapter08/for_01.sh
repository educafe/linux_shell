#!/bin/bash
for var in {1..10}
do
echo $var
done
