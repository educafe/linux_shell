#!/bin/bash
for var in 11 12 13 14 15 16 17 18 19 20
do
echo $var
done
