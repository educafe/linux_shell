#!/bin/sh
for var in $*
do
echo "command line contains: $var"
done
