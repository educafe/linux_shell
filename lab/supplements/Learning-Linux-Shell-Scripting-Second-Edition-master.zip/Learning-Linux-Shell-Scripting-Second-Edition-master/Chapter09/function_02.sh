#!/bin/bash
function greet()
{ echo "Hello $LOGNAME, today is $(date)"; }
greet
