#!/bin/bash
hello()
{ echo "Executing function hello"
}
echo "Script has started now"
hello
echo "Script will end"
