#!/bin/bash
yesterday()
{
date --date='1 day ago'
}
yesterday
