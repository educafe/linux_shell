#!/bin/bash
function_lister ()
{
echo Your present working directory is `pwd`
echo Your files are:
ls
}
function_lister
