#!/bin/bash
x=5
y=2
z=`expr $x + $y`
echo $z
