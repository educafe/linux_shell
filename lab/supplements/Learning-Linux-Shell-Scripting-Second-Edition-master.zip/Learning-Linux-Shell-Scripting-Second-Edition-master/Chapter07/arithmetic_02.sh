#!/bin/bash
var1=30
var2=20
echo `expr $var1 + $var2` # Arithmetic Addition
echo `expr $var1 - $var2` # Arithmetic Subtraction
echo `expr $var1 \* $var2` # Arithmetic Multiplication
echo `expr $var1 / $var2` # Arithmetic Division
echo `expr $var1 % $var2` # Arithmetic Modular Division
# (Remainder)
