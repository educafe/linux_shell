#!/bin/bash
# Script is For Demonstrating Arithmetic
var1=10
var2=20
echo $(($var1+$var2)) # Adding Two Values
echo $(($var1-$var2)) # Subtract Two Values
echo $(($var1*$var2)) # Multiply Two Values
echo $(($var1%$var2)) # Remainder
