#!/bin/bash
mysql -u root -pTraining2@^ <<MY_QUERY
show databases;
MY_QUERY

