#!/bin/bash

mysql -u user1 -pTest623@! <<MY_QUERY

DROP DATABASE testdb;

MY_QUERY

