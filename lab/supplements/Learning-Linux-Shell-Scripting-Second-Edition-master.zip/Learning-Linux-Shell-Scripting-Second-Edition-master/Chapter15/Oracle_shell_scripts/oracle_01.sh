#!/bin/bash

sqlplus user1/Test123 <<MY_QUERY

define

MY_QUERY
